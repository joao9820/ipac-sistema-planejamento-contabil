<?php
if (!defined('URL')) {
    header("Location: /");
    exit();
}
?>
        </div><!-- #END div flex - conteudo -->
        <!--
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
        -->

        <!-- jquery/3.3.1 -->
        <!--<script src="<?php echo URLADM.'assets/js/jquery-3.3.1.slim.min.js'; ?>"></script>-->
        <script src="<?php echo URLADM.'assets/js/jquery.min.js'; ?>"></script>
        <!-- popper/1.14.3 -->
        <script src="<?php echo URLADM.'assets/js/popper.min.js'; ?>"></script>
        <!-- bootstrap/4.1.3 -->
        <script src="<?php echo URLADM.'assets/js/bootstrap.min.js'; ?>"></script>

        <script src="<?php echo URLADM.'assets/js/dashboard.js'; ?>"></script>
        <!-- CARREGAR USUARIOS USANDO JS -->
        <script src="<?php echo URLADM.'assets/js/usuarios.js'; ?>"></script>

    </body>
</html>