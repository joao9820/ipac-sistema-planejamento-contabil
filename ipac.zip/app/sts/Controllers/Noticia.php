<?php

namespace App\sts\Controllers;

if (!defined('URL')) {
    header("Location: /");
    exit();
}


class Noticia
{

    public function listar()
    {

    }

}
