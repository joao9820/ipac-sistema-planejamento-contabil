<?php
/**
 * Created by PhpStorm.
 * User: Dhemes
 * Date: 15/02/2019
 * Time: 16:11
 */

namespace App\adms\Models;


if (!defined('URL')) {
    header("Location: /");
    exit();
}

class AdmsAtividadeAntecessoraSucessora
{


    
}