# Sistema Ipac
Sistema web para gereciamento de atividade dos funcionário da empresa.
O sistema também permitirá ao cliente acompanhar todo o processo do seu atendimento.

# Ferramentas
-PHP 7.2
-MySQL
-JavaScript
-Bootstrap
-Webserver